package com.example.plantracker;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class AddNumActivity extends AppCompatActivity {
    EditText mPhoneNumberEditText;
    EditText mPlanNameEditText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_num);
        mPhoneNumberEditText = findViewById(R.id.phone_number);
        mPlanNameEditText = findViewById(R.id.plan_name);
    }
    public void insertPlanNum(View view){
        MyDatabaseHelper dbHelper=new MyDatabaseHelper(this);
        SQLiteDatabase db=dbHelper.getWritableDatabase();
        dbHelper.insertPlanNum(mPhoneNumberEditText.getText().toString().trim(),mPlanNameEditText.getText().toString().trim());
        mPhoneNumberEditText.setText("");
        mPlanNameEditText.setText("");
    }
}
package com.example.plantracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    MyDatabaseHelper dbHelper;
    ArrayList<String> planname, plannum;
    EditText num;
    Button btnAddPlan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        num=findViewById(R.id.txtnum);
        dbHelper = new MyDatabaseHelper(MainActivity.this);
        planname = new ArrayList<>();
        plannum = new ArrayList<>();
        btnAddPlan = findViewById(R.id.btn_addplan);
        btnAddPlan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddPlanActivity.class);
                startActivity(intent);
            }
        });

    }
    public void delnum(View view) {
        String phoneNumber = num.getText().toString();
        try {
            MyDatabaseHelper dbHelper = new MyDatabaseHelper(getApplicationContext());
            dbHelper.deletePlanNum(phoneNumber);
            boolean isDeleted = dbHelper.deletePlanNum(phoneNumber);

            if (isDeleted) {
                Toast.makeText(MainActivity.this, "Failed to delete PlanNum", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(MainActivity.this, "Phone Number deleted successfully", Toast.LENGTH_SHORT).show();
            }

            dbHelper.close();
        }
        catch (Exception e) {
            Toast.makeText(this, "Error", Toast.LENGTH_SHORT).show();
        }

    }
    public void checkplan(View view) {
        try {
            String phoneNumber = num.getText().toString().trim();
            if (TextUtils.isEmpty(phoneNumber)) {
                Toast.makeText(MainActivity.this, "Please enter a phone number", Toast.LENGTH_SHORT).show();
                return;
            }
            else if (phoneNumber.length() != 10) {
                Toast.makeText(MainActivity.this, "Please enter a valid 10-digit phone number", Toast.LENGTH_SHORT).show();
                return;
            }
            MyDatabaseHelper dbHelper = new MyDatabaseHelper(view.getContext());
            String planName = dbHelper.getPlanByPhoneNumber(phoneNumber);
            if (planName == null) {
                Toast.makeText(this, "No plan found for the given phone number", Toast.LENGTH_SHORT).show();
            }
            else {
                Toast.makeText(this, "Plan name: " + planName, Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void displayData(View view) {
        Cursor cursor = dbHelper.readAllData();
        if(cursor.getCount() == 0)
        {
            Toast.makeText(this, "No data", Toast.LENGTH_SHORT).show();
        }
        else {
            while (cursor.moveToNext()){
                planname.add(cursor.getString(0));
                plannum.add(cursor.getString(1));
            }
        }
        Intent intent = new Intent(MainActivity.this, ShowAllActivity.class);
        intent.putStringArrayListExtra("PLAN_NAME_LIST", planname);
        intent.putStringArrayListExtra("PHONE_NUMBER_LIST", plannum);
        startActivity(intent);

    }
    public void addnum(View view){
        new MyDatabaseHelper(this);
        startActivity(new Intent(this,AddNumActivity.class));
    }
}
package com.example.plantracker;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddPlanActivity extends AppCompatActivity {
    Button btnSubmit;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_plan);


    }
    public void addplan(View view)
    {
        EditText pname = findViewById(R.id.txt_name);
        EditText pdata = findViewById(R.id.txtdata);
        EditText ptime = findViewById(R.id.txt_time);
        EditText pmsg = findViewById(R.id.txtmsg);
        EditText pdate = findViewById(R.id.txtdate);
        EditText pothers = findViewById(R.id.txt_others);

        String name = pname.getText().toString();
        String data = pdata.getText().toString();
        String time = ptime.getText().toString();
        String msg = pmsg.getText().toString();
        String date = pdate.getText().toString();
        String others = pothers.getText().toString();

        MyDatabaseHelper dbHelper = new MyDatabaseHelper(AddPlanActivity.this);
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("data", data);
        values.put("time", time);
        values.put("msg", msg);
        values.put("date", date);
        values.put("others", others);

        long newRowId = db.insert("Plans", null, values);
        if (newRowId > -1) {
            Toast.makeText(AddPlanActivity.this, "Error", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(AddPlanActivity.this, "Data saved to database", Toast.LENGTH_SHORT).show();
        }
    }
}

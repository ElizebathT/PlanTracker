package com.example.plantracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class MyDatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "Tracker.db";
    private final Context context;
    private static final int DATABASE_VERSION = 1;
    private static final String CNO = "plannum";
    private static final String CNAME = "planname";
    private static final String TABLE_NAME = "T1";
    public MyDatabaseHelper(@Nullable Context context) {
        super(context,DATABASE_NAME, null, DATABASE_VERSION);
        this.context = context;

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String qry = "create table " + TABLE_NAME + " (" + CNAME + " TEXT, " + CNO + " TEXT);";
        db.execSQL(qry);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
    public boolean deletePlanNum(String phoneNumber) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.delete(TABLE_NAME, CNO + " = ?", new String[]{phoneNumber}) > 0;
    }

    void insertPlanNum(String phoneNumber, String planName) {
        SQLiteDatabase db=this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(CNAME, planName);
        values.put(CNO, phoneNumber);
        long res = db.insert(TABLE_NAME, null, values);
        if(res == -1) {
            Toast.makeText(context, "Failed", Toast.LENGTH_SHORT).show();
        }
        else {
            Toast.makeText(context, "Success", Toast.LENGTH_SHORT).show();
        }
    }
    public String getPlanByPhoneNumber(String phoneNumber) {
        SQLiteDatabase db = this.getReadableDatabase();

        String[] projection = {
                CNAME
        };

        String selection = CNO + " = ?";
        String[] selectionArgs = { phoneNumber };
        Cursor cursor = db.query(
                TABLE_NAME,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        String planName = null;
        if (cursor.moveToFirst()) {
            planName = cursor.getString(cursor.getColumnIndexOrThrow(CNAME));
        }
        cursor.close();

        return planName;
    }

    Cursor readAllData() {
        String qry = "SELECT * FROM " + TABLE_NAME;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = null;
        if (db != null) {
            cursor = db.rawQuery(qry, null);
        }
        return cursor;
    }

}

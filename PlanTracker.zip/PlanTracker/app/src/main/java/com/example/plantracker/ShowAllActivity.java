package com.example.plantracker;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;

public class ShowAllActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_all);

        ArrayList<String> plannameList = getIntent().getStringArrayListExtra("PLAN_NAME_LIST");
        ArrayList<String> phonenumberList = getIntent().getStringArrayListExtra("PHONE_NUMBER_LIST");

        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) TextView plannameTextView = findViewById(R.id.plannameTextView);
        @SuppressLint({"MissingInflatedId", "LocalSuppress"}) TextView phonenumberTextView = findViewById(R.id.phonenumberTextView);

        StringBuilder plannameBuilder = new StringBuilder();
        StringBuilder phonenumberBuilder = new StringBuilder();
        for (int i = 0; i < plannameList.size(); i++) {
            plannameBuilder.append(plannameList.get(i)).append("\n");
            phonenumberBuilder.append(phonenumberList.get(i)).append("\n");
        }
        plannameTextView.setText(plannameBuilder.toString());
        phonenumberTextView.setText(phonenumberBuilder.toString());
    }

}